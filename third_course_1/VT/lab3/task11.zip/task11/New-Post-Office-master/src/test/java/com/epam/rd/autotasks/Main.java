package com.epam.rd.autotasks;

public class Main {
    public static void main(String[] args) {
        // Add your code here if it needed
    }
}
